﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Othello.Game;
using System.Reflection;
using System.Numerics;
using System.Windows.Documents;

namespace Othello.Controller
{
    /// <summary>
    /// The GameManager class is responsible for managing the overall state of the Othello game.
    /// It keeps track of the game board, players, scores, and game status.
    /// </summary>
    public class GameManager
    {

        /// <summary>
        /// The game board being used in the game
        /// </summary>
        private GameBoard gameBoard;

        public GameBoard GameBoard
        {
            get { return gameBoard; }
        }
        /// <summary>
        /// First player in the game
        /// </summary>
        private Player player1;
        public string Player1
        {
            get { return player1.GetName(); }
        }
        /// <summary>
        /// Second player in the game
        /// </summary>
        private Player player2;
        public string Player2
        {
            get { return player2.GetName(); }
        }
        /// <summary>
        /// The current player's turn
        /// </summary>
        private Player currentPlayer;

        public Player CurrentPlayer
        {
            get { return currentPlayer; }
        }
        
  
        public string CurrentPlayerName
        {
            get { return currentPlayer.GetName(); }


        }
        private int turn;
        private int whiteScore;
        public int WhiteScore
        {
            get { return whiteScore; }
        }
        private int blackScore;
        public int BlackScore
        {
            get { return blackScore; }
        }
        private int whitePieces;
        private int blackPieces;
        private int emptyPieces;
        private int totalPieces;
        private bool gameOver;

        public enum Piece
        {
            White = 1,
            Black = 2,
            Empty = 0
        }  

        /// <summary>
        /// Whether the game is against a computer or not
        /// </summary>
        private bool playAgainstComputer;
        public bool PlayAgainstComputer
        {
            set { playAgainstComputer = value; }
        }



        public GameManager()
        {
            gameBoard = new GameBoard();
            turn = 0;
            whiteScore = 0;
            blackScore = 0;
            whitePieces = 0;
            blackPieces = 0;
            emptyPieces = 0;
            totalPieces = 0;
            gameOver = false;
        }

        /// <summary>
        /// Method to setup the game, create player objects and set the current player
        /// </summary>
        /// <param name="player1Name">Name of player 1</param>
        /// <param name="player2Name">Name of player 2</param>
        /// <param name="player1IsHuman">Boolean to indicate if player 1 is human</param>
        /// <param name="player2IsHuman">Boolean to indicate if player 2 is human</param>
        public void SetupGame(string player1Name,string player2Name,bool player1IsHuman,bool player2IsHuman)
        {
            if (playAgainstComputer == true)
            {
                player2 = new ComputerPlayer("Computer", Piece.Black);
            }
            else
            {
                player2 = new HumanPlayer(player2Name, Piece.Black);
            }
            
            player1 = new HumanPlayer(player1Name, Piece.White);
            
            currentPlayer = player1;
        }

        /// <summary>
        /// Method to play the game, update the board state, scores, and check if the game is over
        /// </summary>
        /// <param name="r">Row of the move</param>
        /// <param name="c">Column of the move</param>
        /// <returns>Boolean indicating if the game is still ongoing</returns>
        public bool PlayGame(int r, int c)
        {
            //Make a move for the player
            (r,c) = currentPlayer.MakeMove(gameBoard, r, c);
            //Flip affected bricks
            gameBoard.UpdateBoardState(currentPlayer, r, c);
            UpdateScore();
            Console.WriteLine("--------------");
            PrintBoard();



            if (!GameOver()) 
            {
                SwitchTurn();
                if (!gameBoard.HasValidMove(currentPlayer)) //Ifall spelarn kan inte lägga switcha turn (vi vet att den andra kan lägga eftersom det är inte gameover ändå)
                {
                    SwitchTurn();
               
                }
                Console.WriteLine("fortsätt");
                return true;
                
            }
            else
            {
                Console.WriteLine("game over");
                return false;
            }
        }


        public void UpdateScore()
        {
            whiteScore = 0;
            blackScore = 0;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (gameBoard.GetPiece(i, j) == Piece.White)
                    {
                        whiteScore++;
                    }
                    if (gameBoard.GetPiece(i, j) == Piece.Black)
                    {
                        blackScore++;
                    }
                }
            }
        }

        public bool GameOver()
        {
            if (!gameBoard.HasValidMove(player1) && !gameBoard.HasValidMove(player2))
            {
                Console.WriteLine("Game Over");
                return true;
            }
            return false;
        }

        public void PrintBoard()
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Console.Write(gameBoard.GetPiece(i, j).ToString() + " ");
                }
                Console.WriteLine();
            }
        }

        public void SwitchTurn()
        {
            if (currentPlayer == player1)
            {
                currentPlayer = player2;
            }
            else
            {
                currentPlayer = player1;
            }
        }
    }
}
