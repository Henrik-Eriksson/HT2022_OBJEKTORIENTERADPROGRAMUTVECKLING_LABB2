﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Othello.Controller.GameManager;
using System.Threading;

namespace Othello.Game
{
    class ComputerPlayer : Player
    {


        /// <summary>
        /// ComputerPlayer class is a type of player that represents computer player in the Othello game.
        /// It inherits from the Player class and overrides the MakeMove method to make a move based on the game rules
        /// and the state of the game board.
        /// </summary>
        public ComputerPlayer(string name, Piece piece) : base(name, piece)
        {
            
        }


        /// <summary>
        /// Overrides the MakeMove method to make a move on the game board based on the current state of the game board and the game rules.
        /// </summary>
        /// <param name="board">The game board object</param>
        /// <param name="player">Current player object</param>
        /// <returns>A tuple containing the row and column of the move made by the computer player</returns>
        public override Tuple<int,int> MakeMove(GameBoard board, int r, int c)
        {
            
            int index = 0;
            // Create a list  
            var validMoves = new List<Tuple<int, int>>()
            {
            };
            
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (board.IsValidMove(j, i, this.PlayerPiece))
                    {
                        validMoves.Add(new Tuple<int, int>(j, i));
                    }
                }
            }


            //Randomly select a move from the list
            Random rnd = new Random();
            index = rnd.Next(validMoves.Count);
            board.SetPiece(validMoves[index].Item1, validMoves[index].Item2, this.PlayerPiece);
            
            return (new Tuple<int, int>(validMoves[index].Item1, validMoves[index].Item2));
        }
    }
}
