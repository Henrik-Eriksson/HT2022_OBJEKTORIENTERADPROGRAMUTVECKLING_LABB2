﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Othello.View;
using System.Windows;
using static Othello.Controller.GameManager;


namespace Othello.Game
{

    /// <summary>
    /// The GameBoard class is responsible for managing the state of the Othello game board. 
    /// The class has a 2D array called board that represents the game board, with values of 1 representing white pieces, 
    /// 2 representing black pieces, and 0 representing empty spaces.
    /// The class has methods such as GetPiece, SetPiece, IsValidMove, hasPossibleToFlip, UpdateBoardState and flipDiscs which help in managing the
    /// state of the game board and determining valid moves for players.
    /// The GetPiece method returns the value of a specific cell on the board, the SetPiece method sets the value of
    /// a specific cell on the board, the IsValidMove method checks if a specific move is valid for the current player, 
    /// the hasPossibleToFlip method checks if there are any opponent discs on a specific path, the UpdateBoardState method updates the board state after a move is made and the flipDiscs method 
    /// flips the discs of the opponent player to the current player's color.
    /// The class also has private helper methods such as GetPlayerNumber and GetOpponentPlayerNumber 
    /// which are used to determine the current player's number and the opponent player's number respectively.
    /// Overall, the GameBoard class manages the state of the game board and provides methods for determining valid moves and updating the board state.
    /// </summary>
    public class GameBoard
    {

        private Piece[,] board;

        /// <summary>
        /// Creates a new instance of the GameBoard class and sets the initial state of the board with the starting pieces.
        /// </summary>
        public GameBoard()
        {
            board = new Piece[8, 8];
           // Application.Current.MainWindow;
            SetPiece(3, 3, Piece.White); //white bro
            SetPiece(3, 4, Piece.Black);
            SetPiece(4, 3, Piece.Black);
            SetPiece(4, 4, Piece.White);
        }

        /// <summary>
        /// Gets the piece at a given position on the board.
        /// </summary>
        /// <param name="row">The row of the piece</param>
        /// <param name="col">The column of the piece</param>
        /// <returns>The piece at the given position</returns>
        public Piece GetPiece(int row, int col)
        {
            return board[row, col];
        }


        /// <summary>
        /// Sets a piece at a given position on the board.
        /// </summary>
        /// <param name="row">The row of the piece</param>
        /// <param name="col">The column of the piece</param>
        /// <param name="currentPlayer">The player number of the piece to set (1 for white, 2 for black)</param>
        public void SetPiece(int row, int col, Piece piece)
        {
            board[row, col] = piece;
        }
        
        /// <summary>
        /// Checks if a move is valid at a given position on the board for a given player.
        /// </summary>
        /// <param name="row">The row of the move</param>
        /// <param name="col">The column of the move</param>
        /// <param name="piece">The player number of the piece making the move (1 for white, 2 for black)</param>
        /// <returns>True if the move is valid, false otherwise</returns>
        public bool IsValidMove(int row, int col, Piece piece)
        {
            Piece opponent = piece == Piece.White ? Piece.Black : Piece.White; //hittepå
            
            if (board[row, col] != 0)
            {
                return false;
            }

            int[] dr = { -1, -1, -1, 0, 1, 1, 1, 0 };
            int[] dc = { -1, 0, 1, 1, 1, 0, -1, -1 };

            for (int dir = 0; dir < 8; dir++)
            {
                int newRow = row + dr[dir];
                int newCol = col + dc[dir];

                bool foundOpponent = false;

                while (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8)
                {
                    if (board[newRow, newCol] == opponent)
                    {
                        foundOpponent = true;
                    }
                    else if (board[newRow, newCol] == piece && foundOpponent)
                    {
                        return true;
                    }
                    else
                    {
                        break;
                    }

                    newRow += dr[dir];
                    newCol += dc[dir];
                }
            }

            return false;
        }


        // Check if any opponent discs on a given path
        private bool hasPossibleToFlip(
            Player i_Player,
            int i_Row,
            int i_Col,
            int i_DirectionRow,
            int i_DirectionCol
        )
        {
            bool isPossible = true;

            int rowToCheck = i_Row + i_DirectionRow;
            int colToCheck = i_Col + i_DirectionCol;


     
            while (
                rowToCheck >= 0
                && rowToCheck < board.GetLength(0)
                && colToCheck >= 0
                && colToCheck < board.GetLength(0)
                && (GetPiece(rowToCheck, colToCheck) != i_Player.PlayerPiece)
            )
            {
                rowToCheck += i_DirectionRow;
                colToCheck += i_DirectionCol;
            }

            if (
                rowToCheck < 0
                || rowToCheck > board.GetLength(0) - 1
                || colToCheck < 0
                || colToCheck > board.GetLength(0) - 1
                || (rowToCheck - i_DirectionRow == i_Row && colToCheck - i_DirectionCol == i_Col)
                || GetPiece(rowToCheck, colToCheck) != (i_Player.PlayerPiece)
            )
            {
                isPossible = false;
            }
            return isPossible;
        }

        public void UpdateBoardState(Player i_Player, int i_Row, int i_Col)
        {
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (hasPossibleToFlip(i_Player, i_Row, i_Col, i, j))
                    {
                        SetPiece(i_Row, i_Col, i_Player.PlayerPiece);
                        int rowToChange = i_Row + i;
                        int colToChange = i_Col + j;

                        while (GetPiece(rowToChange, colToChange) != i_Player.PlayerPiece)
                        {
                            SetPiece(rowToChange, colToChange, i_Player.PlayerPiece);
                            rowToChange += i;
                            colToChange += j;
                        }
                    }
                }
            }
        }
        public bool HasValidMove(Player player)
        {
            for (int r = 0; r < 7; r++)
            {
                for (int c = 0; c < 7; c++)
                {
                    if (IsValidMove(r, c, player.PlayerPiece))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}
