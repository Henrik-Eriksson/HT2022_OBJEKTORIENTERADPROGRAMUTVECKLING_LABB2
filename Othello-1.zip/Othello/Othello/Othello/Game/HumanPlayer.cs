﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Othello.Controller;
using static Othello.Controller.GameManager;

/// <summary>
/// The above code is for the HumanPlayer class, the HumanPlayer class represents a human player in the Othello game, which is a subclass of the Player class. The HumanPlayer class is used to represent a human player in the Othello game.
/// The class has a constructor which takes in a name and color as parameters and passes them to the base class's constructor.
/// </summary>

namespace Othello.Game
{
    class HumanPlayer : Player
    {
        public HumanPlayer(string name, Piece piece) : base(name, piece)
        {
        }

        public override Tuple<int, int> MakeMove(GameBoard board, int r, int c)
        {
            board.SetPiece(r, c, this.PlayerPiece);
            return (new Tuple<int, int>(r, c));
        }
    }
}