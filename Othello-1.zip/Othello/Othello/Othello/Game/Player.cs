﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Othello.Controller;
using static Othello.Controller.GameManager;

namespace Othello.Game
{
    /// <summary>
    /// The Player class represents a player in the Othello game. It has properties for the player's name and color, 
    /// and methods for getting the player's name, color, and sign (either 1 for white or 2 for black). 
    /// It also has a virtual MakeMove method which is overridden in subclasses for specific types of players.
    /// </summary>
    public class Player
    {
        private string name;
        public Piece PlayerPiece { get; set; }

        

        public Player(string name, Piece piece)
        {        
            this.name = name;
            this.PlayerPiece = piece;
        }

        /// <summary>
        /// The GetName method returns the name of the player.
        /// </summary>
        /// <returns> The name of the player as a string</returns>
        public string GetName()
        {
            return name;
        }

        /// <summary>
        /// The MakeMove method is a virtual method which is overridden in subclasses for specific types of players, 
        /// When a player needs to determine its move on its own (no mouse clicks) using a specified algorithm.
        /// </summary>
        /// <param name="board"> The current state of the game board.</param>
        /// <param name="player"> The current player making the move.</param>
        /// <returns> A tuple representing the row and column of the move made (0,0 by default).</returns>
        public virtual Tuple<int, int> MakeMove(GameBoard board, int r, int c)
        {
            return (new Tuple<int, int>(0, 0));
            
        }
    }
}
