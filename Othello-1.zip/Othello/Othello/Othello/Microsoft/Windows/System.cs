﻿namespace Microsoft.Windows
{
    internal class System
    {
    }
}