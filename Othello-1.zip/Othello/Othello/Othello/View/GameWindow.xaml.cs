﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Othello.Controller;
using Othello.Game;
using System.Threading;
using static Othello.Controller.GameManager;

namespace Othello.View
{
    /// <summary>
    /// Interaction logic for GameWindow.xaml
    /// </summary>
    /// 


    public partial class GameWindow : Window
    {
        public static int c = 0;
        public static int r = 0;
        // Window window1;

        public GameManager game;

        public Piece getCurrentPiece()
        {
            return this.game.CurrentPlayer.PlayerPiece;
        }

        public void showValidMoves()
        {
            Piece piece = getCurrentPiece();
            
            
            for (int c = 0; c < 8; c++)
            {
                for (int r = 0; r < 8; r++)
                {
                    if (game.GameBoard.IsValidMove(r, c, piece))
                    {
                        foreach (UIElement uie in Grid.Children)
                        {
                            if (Grid.GetColumn(uie) == c && Grid.GetRow(uie) == r)
                            {
                                uie.GetType().GetProperty("Stroke").SetValue(uie, Brushes.Pink);
                            }

                        }
                    }
                }
            }

        }

        public void removeOldValidMoves()
        {
            foreach (UIElement uie in Grid.Children) //RESETTA ALLTING TA BORT PINK 
            {

                if (uie.GetType().GetProperty("Stroke").GetValue(uie) == Brushes.Pink)
                {
                    uie.GetType().GetProperty("Stroke").SetValue(uie, Brushes.White);
                }

            }
        }

        public void showCircle(UIElement element, SolidColorBrush color)
        {
            element.GetType().GetProperty("Fill").SetValue(element, color);
            element.GetType().GetProperty("Stroke").SetValue(element, Brushes.Black);
        }

        public GameWindow(GameManager game)
        {
            this.game = game;
            InitializeComponent();
            player1name.Text = this.game.Player1;
            ScoreP1.Text = "Score";
            nameP2.Text = this.game.Player2;
            scoreP2.Text = "Score";
            turn.Text = this.game.CurrentPlayerName + "'s turn"; //Currentplayer was null
            bricksP1.Text = "2";
            bricksP2.Text = "2";
            showValidMoves();
            
        }

        private void finishTurn()
        {

            //UPDATE THE INTERNAL GAME LOGIC


            if (!game.PlayGame(r, c))
            {
                var gameover = new WinnerDialog(game);
                gameover.Show();
            }
    


            turn.Text = game.CurrentPlayer.GetName() + "'s turn";
            bricksP1.Text = game.WhiteScore.ToString();
            bricksP2.Text = game.BlackScore.ToString();
            
            removeOldValidMoves();

            Piece piece =
              default;

            //UPPDATERA EVENTUELLA SWITCHADE BRICKOR
            for (int col = 0; col < 8; col++)
            {
                for (int row = 0; row < 8; row++)
                {

                    piece = game.GameBoard.GetPiece(row, col);
                    
                    if (piece != Piece.Empty) //If there exists a circle here according to game logic
                    {
                        foreach (UIElement uie in Grid.Children)
                        {
                            if (Grid.GetColumn(uie) == col && Grid.GetRow(uie) == row) //And the circle matches the coords from game logic
                            {
                                if (piece == Piece.White)
                                {
                                    showCircle(uie, new SolidColorBrush(Colors.White)); //Show it as white if the circle is white according to game logic
                                }
                                if (piece == Piece.Black)
                                {
                                    showCircle(uie, new SolidColorBrush(Colors.Black)); //Else black
                                }

                            }

                        }
                    }

                }
            }

            //Show the new valid moves now when the graphic updated the flipped circles
            showValidMoves();
        }
        
        private async void Grid_MouseDown(object sender, MouseEventArgs e)
        {
            var element = (UIElement)e.Source;

            c = Grid.GetColumn(element);
            r = Grid.GetRow(element);
            Piece piece = getCurrentPiece();
            

            //If the user has clicked a valid grid
            if (game.GameBoard.IsValidMove(r, c, piece))
            {
                if (element.GetType().GetProperty("Fill") != null) //Make sure it's not clicked on a edge
                {
                    finishTurn();

                }
            }


            //If playing against the computer wait before allowing to click again and let computer play
            if (game.CurrentPlayer is ComputerPlayer)
            {
                Grid.IsEnabled = false;

                // Move the computer's logic to a background thread
                await Task.Run(() =>
                {
                    Thread.Sleep(1000);
                    Dispatcher.Invoke(() =>
                    {
                        finishTurn();
                        Grid.IsEnabled = true;
                    });
                });
            }

        }
    }
}    

