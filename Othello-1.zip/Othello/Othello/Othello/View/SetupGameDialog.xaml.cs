﻿using Othello.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Othello.View;

namespace Othello.View
{
    public partial class SetupGameDialog : Window
    {

        public GameManager game;
        public SetupGameDialog(GameManager game)
        {
            Window window1;
            InitializeComponent();
            this.game = game;
        }

        private void playButton(object sender, RoutedEventArgs e)
        {

            bool computer = default;

            if (againstComputer.IsChecked ?? false) //null coalescing operator
            {
                computer = true;
            }
            if (player1Name.Text == "")
            {
                player1Name.Text = "Player 1";
            }

            if (!computer)
            {
                if (player2Name.Text == "")
                {
                    player2Name.Text = "Player 2";
                }
            }
        

            game.SetupGame(player1Name.Text, player2Name.Text, true, computer);
            
            var window3 = new GameWindow(game);
            
            window3.Show();
            
           

        }

        private void againstComputer_Checked(object sender, RoutedEventArgs e)
        {
            game.PlayAgainstComputer = true;
        }

        private void Exit_button_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        //P1
        private void player1Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        //P2
        private void player2Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}