﻿using Othello.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Othello.View
{
    /// <summary>
    /// Interaction logic for WinnerDialog.xaml
    /// </summary>
    public partial class WinnerDialog : Window
    {
        public WinnerDialog(GameManager game)
        {
            InitializeComponent();


            if (game.WhiteScore > game.BlackScore)
            {
                winner.Text = "The winner is " + game.Player1;
            } 
             else
            {
                if (game.Player2 == "Computer")
                {
                    trophy.Source = null;

                    thumbsup.Source = new BitmapImage(new Uri(@"/Resources/sad.gif", UriKind.Relative));

                }
                winner.Text = "The winner is " + game.Player2;
            }

            
        }

        private void winner_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
